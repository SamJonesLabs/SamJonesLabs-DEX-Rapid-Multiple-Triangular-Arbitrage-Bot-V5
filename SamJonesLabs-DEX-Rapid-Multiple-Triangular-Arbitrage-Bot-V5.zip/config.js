var myaddress = "your ETH public address"
var myprivatekey = "your private key to that address" 
var myseed = "your wallet seed" //if your privatekey is stored in a wallet with no privatekey accessibility example a (hardwarewallet) make sure you still input your pubilc ETH address
var networks = "1" //1 = ETH , 56 = BNB , 137 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.